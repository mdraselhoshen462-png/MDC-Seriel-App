# MDC Serial - release rules
