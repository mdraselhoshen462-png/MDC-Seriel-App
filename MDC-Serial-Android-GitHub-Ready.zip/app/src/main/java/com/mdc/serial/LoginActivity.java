package com.mdc.serial;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;

public class LoginActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_login);
        EditText u = findViewById(R.id.username);
        EditText p = findViewById(R.id.password);
        TextView login = findViewById(R.id.loginButton);
        login.setOnClickListener(v -> {
            String user = u.getText().toString().trim();
            String pass = p.getText().toString();
            // Temporary local demo login. Firebase Auth will replace this in the next stage.
            if ("admin".equalsIgnoreCase(user) && "admin123".equals(pass)) {
                startActivity(new Intent(this, DashboardActivity.class));
                finish();
            } else {
                Toast.makeText(this, "ইউজারনেম বা পাসওয়ার্ড সঠিক নয়", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
