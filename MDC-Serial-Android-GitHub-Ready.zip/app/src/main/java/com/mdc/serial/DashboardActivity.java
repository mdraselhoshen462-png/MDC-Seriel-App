package com.mdc.serial;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DashboardActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_dashboard);

        TextView date = findViewById(R.id.dateText);
        date.setText(new SimpleDateFormat("dd-MM-yyyy", Locale.US).format(new Date()));

        findViewById(R.id.actionTotal).setOnClickListener(v -> open(TotalSerialActivity.class));
        findViewById(R.id.actionAddSerial).setOnClickListener(v -> open(AddSerialActivity.class));
        findViewById(R.id.actionAddDoctor).setOnClickListener(v -> open(DoctorWiseActivity.class));
        findViewById(R.id.actionAddCareof).setOnClickListener(v -> open(CareOfWiseActivity.class));
        findViewById(R.id.adminButton).setOnClickListener(v -> open(AdminControlActivity.class));
        findViewById(R.id.logout).setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void open(Class<?> c) {
        startActivity(new Intent(this, c));
    }
}
