package com.mdc.serial;

import android.app.Activity;
import android.os.Bundle;

public class TotalSerialActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_total_serial);
    }
}
