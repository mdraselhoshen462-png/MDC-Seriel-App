# MDC Serial — GitHub Ready Android Project

এই projectটি MDC Serial অ্যাপের প্রথম Android build ভিত্তি।

## UI লক্ষ্য
- দেওয়া MDC reference অনুযায়ী compact 2×2 dashboard layout
- Total Serial / Add Serial / Add Doctor / Add Care Of
- Admin Control Panel
- ২০ সেকেন্ডের auto reload নেই
- পরবর্তী ধাপে true pull-to-refresh এবং Firebase data sync যুক্ত হবে
- Doctor-wise ও Care-of-wise filtering Total Serial-এর ভেতরে থাকবে

## Demo login
Username: `admin`
Password: `admin123`

এটি শুধু প্রথম build যাচাই করার জন্য। Production-এ Firebase Authentication + Firestore Security Rules ব্যবহার করা হবে।

## GitHub Actions
`.github/workflows/android.yml` থেকে push বা manual workflow চালালে debug APK তৈরি হবে।
