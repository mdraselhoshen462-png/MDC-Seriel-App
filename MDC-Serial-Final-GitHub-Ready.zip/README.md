# MDC Serial
Compact Moon Diagnostic Center serial app.

Features: 2x2 dashboard actions, hamburger menu, Add Serial, Add Doctor (Admin), Add Care Of, All Serials with Doctor-wise/Care Of-wise tabs, date and person filters, Admin/Operator completion control, and pull-to-refresh.

Firebase Realtime Database is used for shared data. Add your Firebase Android configuration as `app/google-services.json` and configure your Firebase project before production use. This starter intentionally does not contain credentials.
