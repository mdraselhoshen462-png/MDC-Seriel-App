plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace="com.moondiagnostic.app"
    compileSdk=35
    defaultConfig { applicationId="com.moondiagnostic.app"; minSdk=24; targetSdk=35; versionCode=1; versionName="1.0" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-database-ktx")
}
